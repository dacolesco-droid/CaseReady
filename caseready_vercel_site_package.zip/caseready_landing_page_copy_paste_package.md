# CaseReady Landing Page Copy-and-Paste Package

## How to Use This Package

This package is meant to make the website step simple. If you are using GoDaddy Website Builder, the safest path is to create one section at a time and paste the text from this document into the matching blocks. If GoDaddy gives you a headline box, a paragraph box, a button label, and a contact form, you can build the page without writing any code.

The page below is written for a **soft launch**. It is designed to introduce CaseReady clearly, explain the need, and give visitors one simple next step: request early access or start a conversation.

## Recommended Page Structure

| Section | Purpose | What to paste |
|---|---|---|
| **Hero** | Make the visitor understand the product fast | Headline, subheadline, and main button |
| **Problem** | Show the pain CaseReady addresses | Short explanatory paragraph |
| **How It Helps** | Explain the product in plain language | Three short value blocks |
| **Who It Serves** | Broaden relevance beyond one audience | Short audience section |
| **Why Now** | Build urgency and credibility | Short statistics section |
| **Call to Action** | Tell people what to do next | Contact form or button copy |
| **Trust / Disclaimer** | Reduce confusion and risk | Plain-language clarification |

## Exact Copy for the Page

### 1. Hero Section

**Headline**

Get organized before a legal problem gets worse.

**Subheadline**

CaseReady helps people prepare for real-life civil problems like housing issues, debt, workplace disputes, school conflicts, and small-business trouble when they do not know what to do first.

**Primary button**

Request Early Access

**Secondary button**

Bring CaseReady to Your Organization

### 2. Problem Section

**Section title**

Too many people face serious problems without a clear first step.

**Body copy**

Most people do not begin by needing a full lawyer. They begin by feeling overwhelmed. They are trying to gather facts, sort documents, understand timelines, write a first message, or figure out who to contact. When they cannot do that early work, manageable problems can turn into bigger ones.

CaseReady is built for that gap. It helps people get organized before confusion, delay, and stress make the situation worse.

### 3. How It Helps Section

**Section title**

What CaseReady helps people do

| Feature block title | Copy |
|---|---|
| **Organize the facts** | CaseReady helps users pull together the important details of a situation so they can explain the problem clearly. |
| **Prepare documents and next steps** | It helps users think through timelines, records, letters, and first-step written materials before they reach out for help. |
| **Move forward with more confidence** | It gives people structure at the moment they often feel stuck, scattered, or unsure what to do next. |

### 4. Who It Serves Section

**Section title**

Built for people and organizations dealing with real-world pressure.

**Body copy**

CaseReady can support individuals directly, and it can also support universities, employers, community organizations, and public-interest partners that serve people under stress. The need is often the same across all of them: people need help getting organized before they can use outside support well.

**Audience line**

Useful for students, workers, families, community members, and small-business owners.

### 5. Why Now Section

**Section title**

Why this matters now

**Body copy**

The need for early legal-preparation support is larger than many people realize. The Legal Services Corporation reports that low-income Americans do not get any or enough legal help for **92%** of their civil legal problems, and **74%** of low-income households faced at least one civil legal problem in the last year.[1] [2]

In higher education, The Hope Center found that **59%** of surveyed students faced food or housing insecurity.[3] In the workplace, PwC found that **59%** of surveyed employees are stressed about their finances right now.[4] For small businesses, the State Bar of California reported that **4 in 10** owners faced at least one legal issue in the last year.[5]

These problems do not stay neatly contained. They affect retention, productivity, stability, and peace of mind. CaseReady is designed to help people act earlier and more clearly.

### 6. Call to Action Section

**Section title**

Start the conversation.

**Body copy**

If you want to request early access, explore a pilot, or learn how CaseReady could support the people you serve, send a message below.

**Form fields**

| Field label | Suggested text |
|---|---|
| **Name** | Your name |
| **Email** | Your email |
| **Organization** | University, employer, nonprofit, or other |
| **Message** | Tell us what kind of support or pilot you have in mind |

**Submit button**

Contact CaseReady

### 7. Trust and Clarity Section

**Section title**

A practical preparation tool, not a law firm.

**Body copy**

CaseReady is designed to help people get organized, prepare written materials, and understand next steps. It is not a law firm, does not replace a lawyer, and is not a substitute for legal advice.

## Short Version for a Very Simple One-Page Builder

If you want the fastest possible version, paste this shortened copy into a single long section.

> **Get organized before a legal problem gets worse.**
>
> CaseReady helps people prepare for real-life civil problems like housing issues, debt, school conflicts, workplace disputes, and small-business trouble when they do not know what to do first.
>
> Most people do not begin by needing a full lawyer. They begin by needing help collecting facts, sorting documents, understanding timelines, and figuring out their next step. CaseReady is built for that gap.
>
> It helps people organize the facts, prepare documents and early written materials, and move forward with more confidence.
>
> The need is real. The Legal Services Corporation reports that low-income Americans do not get any or enough legal help for 92% of their civil legal problems.[1] [2] The problem also affects students, workers, families, community organizations, and small-business owners.[3] [4] [5]
>
> If you want to request early access, explore a pilot, or learn more, contact us today.
>
> CaseReady is a practical preparation tool. It is not a law firm and does not replace legal advice.

## Suggested Navigation Labels

| Area | Label |
|---|---|
| Top menu item 1 | Home |
| Top menu item 2 | How It Works |
| Top menu item 3 | Who It Helps |
| Top menu item 4 | Contact |
| Main button | Request Early Access |

## Suggested Meta Description

CaseReady helps people get organized before civil legal problems get worse, with practical support for housing, debt, school, work, and small-business issues.

## Suggested Contact Email Label

hello@dacolesco.com

Replace that with your preferred email address if needed.

## References

[1] [The Justice Gap Report — Legal Services Corporation](https://justicegap.lsc.gov/)

[2] [Section 3: The Prevalence of Civil Legal Problems — The Justice Gap Report](https://justicegap.lsc.gov/resource/section-3-the-prevalence-of-civil-legal-problems/)

[3] [2023-2024 Student Basic Needs Survey Report — The Hope Center for Student Basic Needs](https://hope.temple.edu/research/hope-center-basic-needs-survey/2023-2024-student-basic-needs-survey-report)

[4] [2026 Employee Financial Wellness Survey — PwC](https://www.pwc.com/us/en/services/consulting/human-resources/library/employee-financial-wellness-survey.html)

[5] [2024 Justice Gap Study Shows Growing Unmet Legal Needs Amid Shifting Attorney Workforce — The State Bar of California](https://www.calbar.ca.gov/news/2024-justice-gap-study-shows-growing-unmet-legal-needs-amid-shifting-attorney-workforce)
