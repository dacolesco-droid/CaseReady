# CaseReady Vercel Launch Guide

## What I Built

I created a hosted-ready static landing page for CaseReady in this file:

`caseready_vercel_site_index.html`

That file is a simple one-page website. It can be uploaded to Vercel, Netlify, Cloudflare Pages, or almost any static host. For your immediate outreach, **Vercel** is the easiest choice.

## What You Need to Do

You only need three things to get this live.

| Item | What you need | Why it matters |
|---|---|---|
| **1. A Vercel account** | Sign up or sign in at [vercel.com](https://vercel.com/) | This is where the landing page will be hosted |
| **2. Access to the domain** | Login access to wherever `dacolesco.com` or `dacolescoai.com` is managed | This is needed to point the domain to the new site |
| **3. Your preferred contact email** | The email address you want visitors to use | The current page uses `hello@dacolesco.com` as a placeholder |

## My Recommendation on the Domain

Because you said **CaseReady** should lead, my recommendation is to use **`dacolesco.com` as the primary live landing page for now** and have **`dacolescoai.com` redirect to it**. That is the simplest setup for outreach because the shorter domain is easier to say, type, and remember.

## Fastest Launch Path

| Step | What to do |
|---|---|
| **1** | Download the `caseready_vercel_site_index.html` file from this workspace |
| **2** | Rename it to `index.html` if needed |
| **3** | Create a new Vercel project and upload the file through a simple static-site workflow |
| **4** | Point your chosen primary domain to the Vercel project |
| **5** | Change the placeholder email on the page to your real contact email before launch |
| **6** | Redirect the second domain to the primary domain |

## If You Want Me to Help Finish the Hosting Setup

I can help more directly, but you would need to provide access in one of these ways.

| Path | What you would do |
|---|---|
| **Browser-assisted setup** | Open or sign into Vercel when prompted so I can guide the rest |
| **Manual setup with my instructions** | You create the project and domain connection yourself using this guide |
| **Domain-only follow-up** | You tell me which domain will be primary and what email should appear on the site, and I will finalize the page text accordingly |

## One Important Content Change Before Launch

Please decide what email address should replace `hello@dacolesco.com`. Once you choose that, the page will be ready for a clean first launch.

## Suggested Next Move

If you want the fastest route, reply with these two items:

1. **Which domain should be primary:** `dacolesco.com` or `dacolescoai.com`
2. **Which email address should appear on the site**

After that, I can update the page immediately so it is ready for your university and veteran-support outreach.
